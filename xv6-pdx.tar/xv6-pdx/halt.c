// halt the system.
#include "types.h"
#include "user.h"

int
main(void) {
  halt();
  exit();
}
