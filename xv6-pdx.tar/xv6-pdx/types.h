typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  uchar;
typedef uint pde_t;
#ifdef PDX_XV6
#include "pdx.h"
#endif // PDX_XV6
